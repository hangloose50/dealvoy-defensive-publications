# Dealvoy Desktop Release Bundle

This folder contains all files for local deployment, review, and archiving of the Dealvoy system and IP protections.

## Contents
- offline.html (landing page)
- DEFENSIVE_PUBLICATIONS_GLOBAL.pdf (global defensive publication bundle)
- DealvoyAgentManager/ (desktop UI app)
- All 41 agent scripts (for CLI/local execution)
- TRADEMARK_SUBMISSION_GUIDE.md

---

*Prepared July 25, 2025 by GPT Commander for Dustin Newcomb*
