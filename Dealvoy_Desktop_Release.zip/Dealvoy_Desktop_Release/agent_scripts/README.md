# Dealvoy Agent Scripts

This folder contains Python scripts for all 41 Dealvoy AI Voyager agents.

## Usage
- Each script can be run independently for testing
- Used by the AgentManagerApp for toggling and monitoring
- See main documentation for agent descriptions and usage

---

*Prepared by GPT Commander for Dustin Newcomb, July 2025*
